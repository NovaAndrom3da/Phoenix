class PPM():
  from .ppm import (
    install_module as i_mod,
    install_extension as i_ext,
    install as i,
    remove_module as r_mod,
    remove_extension as r_ext,
    remove as r,
    init,
    update as u,
  )
  