import phoenix
import sys

def main():
  phoenix.run()

